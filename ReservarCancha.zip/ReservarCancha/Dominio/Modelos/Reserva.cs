namespace ReservarCancha.Dominio.Modelos;

public class Reserva
{
    public int Id { get; set; }

    public int CanchaId { get; set; }

    public string Cliente { get; set; } = string.Empty;

    public DateTime FechaHora { get; set; }

    public bool Cancelada { get; set; }
}