using ReservarCancha.Dominio.Modelos;
using ReservarCancha.Persistencia;

namespace ReservarCancha.Application;

public class ReservaService
{
    private readonly IReservaRepository _reservaRepository;
    private readonly ICanchaRepository _canchaRepository;

    public ReservaService(
        IReservaRepository reservaRepository,
        ICanchaRepository canchaRepository)
    {
        _reservaRepository = reservaRepository;
        _canchaRepository = canchaRepository;
    }


    public void CrearReserva(Reserva reserva)
{
    if (string.IsNullOrWhiteSpace(reserva.Cliente))
        throw new Exception("Debe ingresar el nombre del cliente.");

    var cancha = _canchaRepository.ObtenerPorId(reserva.CanchaId);

    if (cancha == null)
        throw new Exception("La cancha no existe.");

    _reservaRepository.Agregar(reserva);
}

}